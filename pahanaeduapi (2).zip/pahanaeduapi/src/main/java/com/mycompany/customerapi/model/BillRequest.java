/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.customerapi.model;


import java.util.List;

public class BillRequest {
    private String account_number;
    private List<BillItemRequest> items;

    public String getAccount_number() {
        return account_number;
    }
    public void setAccount_number(String account_number) {
        this.account_number = account_number;
    }

    public List<BillItemRequest> getItems() {
        return items;
    }
    public void setItems(List<BillItemRequest> items) {
        this.items = items;
    }

    public static class BillItemRequest {
        private int item_id;
        private int quantity;

        public int getItem_id() {
            return item_id;
        }
        public void setItem_id(int item_id) {
            this.item_id = item_id;
        }

        public int getQuantity() {
            return quantity;
        }
        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }
    }
}

