package com.mycompany.customerapi.resources;



import com.google.gson.Gson;

import com.mycompany.customerapi.model.Bill;
import com.mycompany.customerapi.model.BillRequest;


import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

public class BillResource {

    private BillDAO billDAO = new BillDAO();
    private Gson gson = new Gson();

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createBill(String json) {
        try {
            BillRequest request = gson.fromJson(json, BillRequest.class);
            Bill bill = billDAO.createBill(request);
            return Response.status(Response.Status.CREATED).entity(gson.toJson(bill)).build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("{\"error\":\"Failed to create bill\"}")
                    .build();
        }
    }
}
