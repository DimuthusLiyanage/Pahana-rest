package com.mycompany.customerapi.service;

import com.mycompany.customerapi.model.Bill;
import com.mycompany.customerapi.model.Bill.BillLineItem;
import com.mycompany.customerapi.utils.DBUtils;
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BillService {
    private final DBUtils dbUtils = new DBUtils();

    // Generate utility bill (electricity/water)
    public Bill generateUtilityBill(String accountNumber) throws SQLException {
        Connection conn = null;
        PreparedStatement psCustomer = null;
        PreparedStatement psBill = null;
        ResultSet rs = null;
        
        try {
            conn = dbUtils.getConnection();
            conn.setAutoCommit(false);
            
            // 1. Get customer's current units
            psCustomer = conn.prepareStatement(
                "SELECT units_consumed FROM customers WHERE account_number = ? FOR UPDATE");
            psCustomer.setString(1, accountNumber);
            rs = psCustomer.executeQuery();
            
            if (!rs.next()) {
                throw new SQLException("Customer not found");
            }
            
            int units = rs.getInt("units_consumed");
            double amount = calculateBillAmount(units);

            // 2. Create bill record
            psBill = conn.prepareStatement(
                "INSERT INTO bills (account_number, bill_date, total_units, amount_due, payment_status) " +
                "VALUES (?, ?, ?, ?, 'PENDING')", 
                Statement.RETURN_GENERATED_KEYS
            );
            psBill.setString(1, accountNumber);
            psBill.setDate(2, new java.sql.Date(new Date().getTime()));
            psBill.setInt(3, units);
            psBill.setDouble(4, amount);
            psBill.executeUpdate();

            // 3. Get generated bill ID
            rs = psBill.getGeneratedKeys();
            int billId = 0;
            if (rs.next()) {
                billId = rs.getInt(1);
            }

            // 4. Reset customer's units
            psCustomer = conn.prepareStatement(
                "UPDATE customers SET units_consumed = 0 WHERE account_number = ?");
            psCustomer.setString(1, accountNumber);
            psCustomer.executeUpdate();

            conn.commit();

            // 5. Create and return bill object
            Bill bill = new Bill();
            bill.setBill_id(billId);
            bill.setAccount_number(accountNumber);
            bill.setBill_date(new Date());
            bill.setTotal_units(units);
            bill.setAmount_due(amount);
            bill.setPayment_status("PENDING");
            bill.setLine_items(new ArrayList<>()); // Empty for utility bills
            
            return bill;

        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw e;
        } finally {
          //  closeResources(rs, psCustomer, psBill, conn);
        }
    }

    // Create itemized bill
    public Bill createItemizedBill(String accountNumber, List<BillLineItem> items) throws SQLException {
        Connection conn = null;
        PreparedStatement psBill = null;
        PreparedStatement psItem = null;
        ResultSet rs = null;
        
        try {
            conn = dbUtils.getConnection();
            conn.setAutoCommit(false);
            
            // 1. Calculate totals
            int totalUnits = 0;
            double totalAmount = 0;
            for (BillLineItem item : items) {
                totalUnits += item.getQuantity();
                totalAmount += (item.getUnit_price() * item.getQuantity());
            }

            // 2. Create bill record
            psBill = conn.prepareStatement(
                "INSERT INTO bills (account_number, bill_date, total_units, amount_due, payment_status) " +
                "VALUES (?, ?, ?, ?, 'PENDING')", 
                Statement.RETURN_GENERATED_KEYS
            );
            psBill.setString(1, accountNumber);
            psBill.setDate(2, new java.sql.Date(new Date().getTime()));
            psBill.setInt(3, totalUnits);
            psBill.setDouble(4, totalAmount);
            psBill.executeUpdate();

            // 3. Get generated bill ID
            rs = psBill.getGeneratedKeys();
            int billId = 0;
            if (rs.next()) {
                billId = rs.getInt(1);
            }

            // 4. Create bill items
            psItem = conn.prepareStatement(
                "INSERT INTO bill_items (bill_id, item_id, quantity, unit_price) " +
                "VALUES (?, ?, ?, ?)"
            );
            
            for (BillLineItem item : items) {
                psItem.setInt(1, billId);
                psItem.setInt(2, item.getItem_id());
                psItem.setInt(3, item.getQuantity());
                psItem.setDouble(4, item.getUnit_price());
                psItem.addBatch();
            }
            psItem.executeBatch();

            conn.commit();

            // 5. Create and return bill object
            Bill bill = new Bill();
            bill.setBill_id(billId);
            bill.setAccount_number(accountNumber);
            bill.setBill_date(new Date());
            bill.setTotal_units(totalUnits);
            bill.setAmount_due(totalAmount);
            bill.setPayment_status("PENDING");
            bill.setLine_items(items);
            
            return bill;

        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw e;
        } finally {
           // closeResources(rs, psBill, psItem, conn);
        }
    }

    // Get bill by ID
    public Bill getBillById(int billId) throws SQLException {
        String billSql = "SELECT * FROM bills WHERE bill_id = ?";
        String itemsSql = "SELECT bi.*, i.name AS item_name " +
                          "FROM bill_items bi " +
                          "JOIN items i ON bi.item_id = i.item_id " +
                          "WHERE bi.bill_id = ?";
        
        try (Connection conn = dbUtils.getConnection();
             PreparedStatement psBill = conn.prepareStatement(billSql);
             PreparedStatement psItems = conn.prepareStatement(itemsSql)) {
            
            // Get bill header
            psBill.setInt(1, billId);
            try (ResultSet rsBill = psBill.executeQuery()) {
                if (rsBill.next()) {
                    Bill bill = new Bill();
                    bill.setBill_id(rsBill.getInt("bill_id"));
                    bill.setAccount_number(rsBill.getString("account_number"));
                    bill.setBill_date(rsBill.getDate("bill_date"));
                    bill.setTotal_units(rsBill.getInt("total_units"));
                    bill.setAmount_due(rsBill.getDouble("amount_due"));
                    bill.setPayment_status(rsBill.getString("payment_status"));
                    
                    // Get bill items
                    psItems.setInt(1, billId);
                    try (ResultSet rsItems = psItems.executeQuery()) {
                        List<BillLineItem> items = new ArrayList<>();
                        while (rsItems.next()) {
                            BillLineItem item = new BillLineItem(
                                rsItems.getInt("item_id"),
                                rsItems.getString("item_name"),
                                rsItems.getDouble("unit_price"),
                                rsItems.getInt("quantity")
                            );
                            items.add(item);
                        }
                        bill.setLine_items(items);
                    }
                    return bill;
                }
            }
        }
        return null;
    }

    // Update bill status
    public boolean updateBillStatus(int billId, String status) throws SQLException {
        String sql = "UPDATE bills SET payment_status = ? WHERE bill_id = ?";
        try (Connection conn = dbUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, billId);
            return ps.executeUpdate() > 0;
        }
    }

    // Get bills by account
    public List<Bill> getBillsByAccount(String accountNumber) throws SQLException {
        String sql = "SELECT * FROM bills WHERE account_number = ?";
        List<Bill> bills = new ArrayList<>();
        
        try (Connection conn = dbUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, accountNumber);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Bill bill = new Bill();
                    bill.setBill_id(rs.getInt("bill_id"));
                    bill.setAccount_number(rs.getString("account_number"));
                    bill.setBill_date(rs.getDate("bill_date"));
                    bill.setTotal_units(rs.getInt("total_units"));
                    bill.setAmount_due(rs.getDouble("amount_due"));
                    bill.setPayment_status(rs.getString("payment_status"));
                    bills.add(bill);
                }
            }
        }
        return bills;
    }

    // Get all bills with optional status filter
    public List<Bill> getAllBills(String statusFilter) throws SQLException {
        String sql = "SELECT * FROM bills";
        if (statusFilter != null && !statusFilter.equalsIgnoreCase("all")) {
            sql += " WHERE payment_status = ?";
        }
        
        List<Bill> bills = new ArrayList<>();
        try (Connection conn = dbUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            if (statusFilter != null && !statusFilter.equalsIgnoreCase("all")) {
                ps.setString(1, statusFilter.toUpperCase());
            }
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Bill bill = new Bill();
                    bill.setBill_id(rs.getInt("bill_id"));
                    bill.setAccount_number(rs.getString("account_number"));
                    bill.setBill_date(rs.getDate("bill_date"));
                    bill.setTotal_units(rs.getInt("total_units"));
                    bill.setAmount_due(rs.getDouble("amount_due"));
                    bill.setPayment_status(rs.getString("payment_status"));
                    bills.add(bill);
                }
            }
        }
        return bills;
    }

    private double calculateBillAmount(int units) {
        // Implement tiered pricing logic
        if (units <= 100) {
            return units * 10.0;
        } else if (units <= 200) {
            return 100 * 10.0 + (units - 100) * 15.0;
        } else {
            return 100 * 10.0 + 100 * 15.0 + (units - 200) * 20.0;
        }
    }

    private void closeResources(ResultSet rs, Statement... statements) {
        try {
            if (rs != null) rs.close();
            for (Statement stmt : statements) {
                if (stmt != null) stmt.close();
            }
        } catch (SQLException e) {
            // Log error
        }
    }
}